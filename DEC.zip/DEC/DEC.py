import torch
import numpy as np
from metrics import cal_clustering_metric
from sklearn import metrics
import random
import warnings
import math
from numpy.matlib import repmat


warnings.filterwarnings('ignore')


class Dataset(torch.utils.data.Dataset):
    def __init__(self, X):
        self.X = X

    def __getitem__(self, idx):
        return self.X[:, idx], idx

    def __len__(self):
        return self.X.shape[1]


class PretrainDoubleLayer(torch.nn.Module):
    def __init__(self, X, dim, device, act, batch_size=128, lr=10**-3):
        super(PretrainDoubleLayer, self).__init__()
        self.X = X
        self.dim = dim
        self.lr = lr
        self.device = device
        self.enc = torch.nn.Linear(X.shape[0], self.dim)
        self.dec = torch.nn.Linear(self.dim, X.shape[0])
        self.batch_size = batch_size
        self.act = act

    def forward(self, x):
        if self.act is not None:
            z = self.act(self.enc(x))
            return z, self.act(self.dec(z))
        else:
            z = self.enc(x)
            return z, self.dec(z)

    def _build_loss(self, x, recons_x):
        size = x.shape[0]
        return torch.norm(x-recons_x, p='fro')**2 / size

    def run(self):
        self.to(self.device)
        optimizer = torch.optim.Adam(self.parameters(), lr=self.lr)
        train_loader = torch.utils.data.DataLoader(Dataset(self.X), batch_size=self.batch_size, shuffle=False)
        loss = 0
        for epoch in range(10):
            for i, batch in enumerate(train_loader):
                x, _ = batch
                optimizer.zero_grad()
                _, recons_x = self(x)
                loss = self._build_loss(x, recons_x)
                loss.backward()
                optimizer.step()
            print('epoch-{}: loss={}'.format(epoch, loss.item()))
        Z, _ = self(self.X.t())
        return Z.t()


class DEC(torch.nn.Module):
    def __init__(self, X, labels, layers=None, gamma =1, sigma =0.1, lam1=1, lam2 = 0.0001, lr=10**-4, device=None, batch_size=128):
        super(DEC, self).__init__()
        if layers is None:
            layers = [X.shape[0], 500, 300]
        if device is None:
            device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        self.layers = layers
        self.device = device
        if not isinstance(X, torch.Tensor):
            X = torch.Tensor(X)
        self.X = X.to(self.device)
        self.labels = labels
        self.lam1 = lam1    # lambda1
        self.lam2 = lam2   # lambda2
        self.sigma = sigma
        self.batch_size = batch_size
        self.n_clusters = len(np.unique(self.labels)) # the number of cluster center
        self.gamma = gamma
        self.nbFoc = self.n_clusters+sum1(self.n_clusters) + 1  # the number of focal set, limit to two focal set
        self.lr = lr  # learning rate
        self._build_up()
        self.alpha = 1
        self.F = (np.arange(2 ** self.n_clusters)[:, None] & (1 << np.arange(self.n_clusters)) > 0)[0:, :].astype(int)
        self.c = np.sum(self.F[1:, :], axis=1)  # the cardinality of the focal set


    def _build_up(self):
        self.act = torch.tanh
        self.enc1 = torch.nn.Linear(self.layers[0], self.layers[1])
        self.enc2 = torch.nn.Linear(self.layers[1], self.layers[2])
        self.dec1 = torch.nn.Linear(self.layers[2], self.layers[1])
        self.dec2 = torch.nn.Linear(self.layers[1], self.layers[0])

    def forward(self, x):
        z = self.act(self.enc1(x))
        z = self.act(self.enc2(z))
        recons_x = self.act(self.dec1(z))
        recons_x = self.act(self.dec2(recons_x))
        return z, recons_x

    def _build_loss(self, z, x, d, m, c, recons_x):
        size = x.shape[0]
        loss = 1/2 * torch.norm(x - recons_x, p='fro') ** 2 / size
        m = m.to(self.device)
        C = (c ** self.alpha).repeat(z.shape[0], 1).to(self.device)
        d_sigma = (1 + self.sigma) * (torch.sqrt(d) + 2 * self.sigma) / (2 * (torch.sqrt(d) + self.sigma))
        m1 = torch.sum(C * d_sigma * m * d)
        loss += (self.lam1 / 2 * m1 / size)
        loss += self.lam2 * (self.enc1.weight.norm()**2 + self.enc1.bias.norm()**2) / size
        loss += self.lam2 * (self.enc2.weight.norm()**2 + self.enc2.bias.norm()**2) / size
        loss += self.lam2 * (self.dec1.weight.norm()**2 + self.dec1.bias.norm()**2) / size
        loss += self.lam2 * (self.dec2.weight.norm()**2 + self.dec2.bias.norm()**2) / size
        return loss

    def run(self):
        self.to(self.device)
        n = len(self.c)
        SUM = []
        for i in range(n):
            if self.c[i] > 2:
                list.append(SUM, i)
        F = np.delete(self.F[1:, :], SUM, axis=0)   # Delete focal set with more than two elements
        b = np.zeros(F.shape[1])
        F = np.insert(F, 0, values=b, axis=0)
        c = np.delete(self.c, SUM, axis=0)
        c = torch.tensor(c).to(self.device)
        self.pretrain()
        Z, _ = self(self.X.t())
        Z = Z.detach().to(self.device)

        print('--------initialize cluster center--------')
        idx = random.sample(list(range(Z.shape[0])), self.n_clusters)
        self.centroids = Z[idx, :] + 10**-6
        self.centroids = self.centroids.to(self.device)
        print('--------initialize gplus--------')
        self.gplus = torch.zeros(self.nbFoc-1, Z.shape[1]).to(self.device)
        for i in range(1, self.nbFoc):
            fi = F[i, :]
            fi = fi.reshape(fi.shape[0], 1)
            truc = repmat(fi, 1, Z.shape[1])
            truc = torch.tensor(truc)
            truc = truc.to(self.device)
            self.gplus[i-1, :] = torch.sum(self.centroids*truc, dim=0)/torch.sum(truc, dim=0)
        print('----------initialize M----------')
        self.M = self._update_M(Z, c)

        print('Starting training......')
        train_loader = torch.utils.data.DataLoader(Dataset(self.X), batch_size=self.batch_size, shuffle=True) # 将数据分成多组
        optimizer = torch.optim.Adam(self.parameters(), lr=self.lr)
        loss = 0
        ACC = []
        NMI = []
        ARI = []
        for epoch in range(100):
            D = self._update_D(Z)
            D = D.to(self.device)
            for i, batch in enumerate(train_loader):
                x, idx = batch    # x: tensor
                optimizer.zero_grad()
                z, recons_x = self(x)
                d = D[idx, :]
                m = self.M[idx, :]
                loss = self._build_loss(z, x, d, m, c, recons_x)
                loss.backward()
                optimizer.step()
            Z, _ = self(self.X.t())
            Z = Z.detach()
            self.clustering(Z, F, c, 30)
            m = self.M.cpu().numpy()
            m1 = np.ones(Z.shape[0]).reshape(1, -1).T - np.sum(m, axis=1).reshape(1, -1).T
            m = np.append(m1, m, axis=1)

            # Calculate pignistic probabilities of the clusters(BetP)
            BetP = np.zeros((Z.shape[0], self.n_clusters))
            mm = np.zeros((Z.shape[0], 2**self.n_clusters))
            truc = np.sum(self.F, axis = 1)
            ind = np.argwhere(truc < 3)
            ind = ind.T
            ind = ind[0]
            num = np.size(ind)
            for i in range(0, num):
                mm[:, ind[i]] = m[:, i]
            for i in range(0, Z.shape[0]):
                bet = betp(mm[i, :])
                BetP[i, :] = bet
            y_pred = BetP.argmax(axis=1)
            ari = metrics.adjusted_rand_score(self.labels, y_pred)
            acc, nmi = cal_clustering_metric(self.labels, y_pred)
            print('epoch-{}, loss={}, ac={}. ari={}. NMI={}'.format(epoch, loss.item(), acc, ari, nmi))
            ACC.append(acc)
            NMI.append(nmi)
            ARI.append(ari)
        print("max_ACC", max(ACC))
        print("max_ARI:", max(ARI))
        print("max_NMI:", max(NMI))

    def pretrain(self):
        string_template = 'Start pretraining-{}......'
        print(string_template.format(1))
        pre1 = PretrainDoubleLayer(self.X, self.layers[1], self.device, self.act, lr=self.lr)
        Z = pre1.run()
        self.enc1.weight = pre1.enc.weight
        self.enc1.bias = pre1.enc.bias
        self.dec2.weight = pre1.dec.weight
        self.dec2.bias = pre1.dec.bias
        print(string_template.format(2))
        pre2 = PretrainDoubleLayer(Z.detach(), self.layers[2], self.device, self.act, lr=self.lr)
        pre2.run()
        self.enc2.weight = pre2.enc.weight
        self.enc2.bias = pre2.enc.bias
        self.dec1.weight = pre2.dec.weight
        self.dec1.bias = pre2.dec.bias

    # update the distance between the sample with the focal set
    def _update_D(self, Z):
        D = torch.zeros(Z.shape[0], self.nbFoc - 1)
        D = D.to(self.device)
        for j in range(0, self.nbFoc - 1):
            one = torch.ones(Z.shape[0], 1).to(self.device)
            plus = self.gplus[j, :]
            plus = plus.reshape(1, Z.shape[1])
            A = Z - torch.mm(one, plus)
            B = torch.diag(torch.mm(A, A.T))
            D[:, j] = B
        return D

    # update the cluster center V
    def clustering(self, Z, F, c, max_iter=100):
        for num in range(max_iter):
            for i in range(1, self.nbFoc):
                fi = F[i, :]
                fi = fi.reshape(fi.shape[0], 1)
                truc = repmat(fi, 1, Z.shape[1])
                truc = torch.tensor(truc)
                truc = truc.to(self.device)
                self.gplus[i - 1, :] = torch.sum(self.centroids * truc, dim=0) / torch.sum(truc, dim=0)
            D = self._update_D(Z)
            d_sigma = (1 + self.sigma) * (torch.sqrt(D) + 2 * self.sigma) / (2 * (torch.sqrt(D) + self.sigma))
            self.M = self._update_M(Z, c)
            A = torch.zeros(self.n_clusters, self.n_clusters).to(self.device)
            for k in range(self.n_clusters):
                for l in range(self.n_clusters):
                    truc = np.zeros(self.n_clusters)
                    truc[k] = 1
                    truc[l] = 1
                    t = repmat(truc, self.nbFoc, 1)
                    indices = [int(i) for (i, val) in enumerate(np.sum((F - t) - abs(F - t), axis=1)) if val == 0]
                    indices = np.array(indices)
                    indices = indices - np.ones(indices.shape)
                    indices = indices.astype(int)
                    for jj in range(len(indices)):
                        j = indices[jj].astype('int')
                        mj = self.M[:, j]
                        dj = d_sigma[:, j]
                        A[l][k] = A[l][k] + float(c[j]) ** (self.alpha - 2) * torch.sum(mj * dj, dim=0)


            B = torch.zeros((self.n_clusters, Z.shape[1])).to(self.device)
            for l in range(self.n_clusters):
                truc = np.zeros(self.n_clusters)
                truc[l] = 1
                t = repmat(truc, self.nbFoc, 1)
                indices = [int(i) for (i, val) in enumerate(np.sum((F - t) - abs(F - t), axis=1)) if val == 0]
                indices = np.array(indices)
                indices = indices - np.ones(len(indices))
                indices = indices.astype(int)

                mi = (c[indices] ** (self.alpha - 1)).repeat(Z.shape[0], 1) * (self.M[:, indices] * d_sigma[:, indices])
                s = torch.sum(mi, dim=1)
                s = s.reshape(s.shape[0], 1)
                mats = s.repeat(1, Z.shape[1]).to(self.device)
                xim = Z * mats
                blq = torch.sum(xim, dim=0)
                B[l, :] = blq

            self.centroids = torch.mm(torch.linalg.inv(A), B).to(self.device)

    # update the evidential partition M
    def _update_M(self, Z, c):
        self.M = torch.zeros((Z.shape[0], self.nbFoc-1)).to(self.device)
        D = self._update_D(Z)
        D = D.to(self.device)
        C = (c**self.alpha).repeat(Z.shape[0], 1)
        D_sigma = (1 + self.sigma) * D / (torch.sqrt(D) + self.sigma)
        T = C * torch.exp(-C * D_sigma / self.gamma)
        self.M = T / torch.sum(T, dim=1).reshape([-1, 1])

        return self.M

def bitget(number, pos):
    return (number >> pos) & 1

def betp(x):
    lm = len(x)
    natoms = round(math.log2(lm))
    if 2**natoms == lm:
        if x[0] == 1:
            OUT = np.ones(natoms)/natoms
        else:
            betp = np.zeros(natoms)
            y= np.zeros(natoms)
            for i in range(1, lm):
                for j in range(0, natoms):
                    y[j] = bitget(i, j)
                betp = betp + x[i]/np.sum(y)*y
            OUT = betp/(1-x[0])
            return OUT

    else:
        print("error")

def sum1(n):
    Sum1 = 0
    for i in range(n):
        Sum1 = Sum1 + i
    return Sum1


if __name__ == '__main__':
    import data_loader as loader
    data, labels = loader.load_USPS()
    data = data.T
    dec = DEC(data, labels, [data.shape[0], 128, 80], sigma = 0.1, gamma = 0.1,  lam1=0.01, lam2=0.0001, batch_size=128, lr=10**-4)
    dec.run()
