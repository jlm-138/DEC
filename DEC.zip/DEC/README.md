## Corresponding Paper

This project corresponds to the paper

[Lianmeng Jiao, Feng Wang, Zhun-Ga Liu, and Quan Pan, "**Deep Evidential Clustering Based on Feature Representation Learning**]

If you have issues, please email: fengwang@mail.nwpu.edu.cn


## Dependency
Now, codes of DEC implemented by pytorch is available: 
- pytorch-1.8.0
- numpy
- scikit-learn 


## Brief Introduction
- DEC.py: the main source code of DEC.
- data_loader.py: load data from matlab files (*.mat). 
- metric.py: codes for evaluation of clustering results. 


Samples to run the code is given as follows
```python
import data_loader as loader
    data, labels = loader.load_USPS()
    data = data.T
    dec = DEC(data, labels, [data.shape[0], 128, 80], sigma = 0.1, gamma = 0.1,  lam1=0.01, lam2=0.0001, batch_size=128, lr=10**-4)
    dec.run()
```

In fact, the data_loader.py is not necessary. You just need to input a numpy-matrix (n * d) into DEC. 


